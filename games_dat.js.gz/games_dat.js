var games_gallery = [
  {
    "url": "https://auroriax.itch.io/gridblocked",
    "thumb": "_plus_gridblocked.png",
    "title": "Gridblocked",
    "author": "Auroriax",
    "homepage": "https://auroriax.itch.io/gridblocked"
  },
  {
    "url": "https://minotalen.itch.io/bodenhorizont",
    "thumb": "_plus_bodenhorizont.png",
    "title": "Bodenhorizont",
    "author": "minotalen",
    "homepage": "https://minotalen.itch.io/"
  },
  {
    "url": "https://minotalen.itch.io/pipetwist",
    "thumb": "_plus_pipetwist.png",
    "title": "Pipe Twist",
    "author": "minotalen",
    "homepage": "https://minotalen.itch.io/"
  },
  {
    "url": "https://minotalen.itch.io/crystalanomaly",
    "thumb": "_plus_anomaly.png",
    "title": "Crystal Anomaly",
    "author": "minotalen",
    "homepage": "https://minotalen.itch.io/"
  },
  {
    "url": "https://boredmatt.itch.io/line-world",
    "thumb": "_plus_lineworld.gif",
    "title": "Line World",
    "author": "BoredMatt",
    "homepage": "https://boredmatt.itch.io/"
  },
  {
    "url": "https://boredmatt.itch.io/beams-and-flowers-2",
    "thumb": "_plus_beamsflowers.gif",
    "title": "Beams and Flowers 2",
    "author": "BoredMatt",
    "homepage": "https://boredmatt.itch.io/"
  },
  {
    "url": "https://boredmatt.itch.io/hex-road-blocks",
    "thumb": "_plus_hexroadblocks.gif",
    "title": "Hex Road Blocks",
    "author": "BoredMatt",
    "homepage": "https://boredmatt.itch.io/"
  },
  {
    "url": "https://vexorian.itch.io/kye-ps",
    "thumb": "_plus_kye.png",
    "title": "Kye.ps",
    "author": "vexorian",
    "homepage": "https://vexorian.itch.io/"
  },
]
